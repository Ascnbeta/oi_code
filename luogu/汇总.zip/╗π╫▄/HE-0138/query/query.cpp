#include<bits/stdc++.h>
using namespace std;
int f(int)
int a,s[5000][5000],d,g,h,j,k,l,ji[100][1100],n;
int main()
{
	freopen("query.in","r",stdin); 
	freopen("query.out","w",stdout); 
	cin>>a;
	for(int i=1;i<a;i++)
	{
		cin>>d>>g;
		s[d][f]=1;
		s[f][d]=1;
	}
	for(int i=1;i<=h;i++)
	{
		cin>>j>>k>>l;
		f(j,k,l)
	}
} 
int f(int ruz,rul,c)
{
	for(int c;c<=ruz-rul+1;c++)
	{
		for(int i=ruz;i+c-1<=rul;ruz++)
		{
			
		}
	}
}
//			
