#include <bits/stdc++.h>
using namespace std;

int main()
{
	freopen("traverse.in", "r", stdin);
	freopen("traverse.out", "w", stdout);
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	cout << 1 << endl;
	return 0;
}
