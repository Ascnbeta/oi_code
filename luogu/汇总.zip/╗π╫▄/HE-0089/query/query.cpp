
#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("query.in", "r", stdin);
	freopen("query.out", "w", stdout);
	cout << 3;
}
