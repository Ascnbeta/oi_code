#include<bits/stdc++.h>
#define int long long
using namespace std;
int rp=0;
signed main(){
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	while(1) cout<<rand()<<'\n';
//freopen("query.in","r",stdin);
//	freopen("query.out","w",stdout);
//freeopen("query.in","r",stdin);
//	freopen("query.out","w",stdout);
//#include<bits\stdc++.h>
//I love zzh
//I love ccf
//NOIP AK me
	return 0;
	while(rp++) rp++;
}
