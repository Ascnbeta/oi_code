#include<bits/stdc++.h>
#define int long long
using namespace std;
const int md=1e9+7;
int c,t;
vector<int>e[100005];
int f[100005];
bool A,B;
signed main()
{
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	cin>>c>>t;
	while(t--)
	{
		puts("1");
	}
}
