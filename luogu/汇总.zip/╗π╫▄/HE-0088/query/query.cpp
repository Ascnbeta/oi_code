#include<bits/stdc++.h>
using namespace std;
#define int long long

const int N=100010,mod=1e9+7;
int T,n,m,v[N],u[N];

signed main(){
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>u[i]>>v[i];
	}
	cin>>m;
	for(int i=1;i<=m;i++){
		cout<<0<<'\n';
	}
	return 0;
}
