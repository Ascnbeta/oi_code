#include <bits/stdc++.h>
using namespace std; 

signed main() {
	freopen("assign.in", "r", stdin); 
	freopen("assign.out", "w", stdout); 
	int T; cin >> T; 
	whie (T --)cout << 0; 
}
