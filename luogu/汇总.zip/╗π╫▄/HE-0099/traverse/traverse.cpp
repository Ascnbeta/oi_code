#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int c,T;
signed main()
{
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	cin>>c>>T;
	while(T--)
	{
		int n,k;
		cin>>n>>k;
		cout<<k<<endl;
	}
	return 0;
}
