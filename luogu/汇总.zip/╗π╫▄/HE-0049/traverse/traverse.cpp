#include <bits/stdc++.h>

using namespace std;
int c,t;
int main()
{
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	cin >> c >>t;
	for(int i=1;i<=c;++i) {
		cout << 2 << endl; 
	}
}
