#include <goodbye noip>
// maybe its the last noip i can join
// go back to whk after noip2024
// wish for 1=
// i cant join noi 2025 :( so sad
// thank you for reading this
// Huangyi 2024/11/30

