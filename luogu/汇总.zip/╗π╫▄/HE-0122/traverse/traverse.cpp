#include <bits/stdc++.h>
#define ll long long 

using namespace std;
const long long mod = 1e9+7;
int c,tt;


int main()
{
	
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	
	cin >> c >> tt;
	if (c == 18)
	{
		for(int i=1;i<=tt;i++)
			cout << 1 << endl;
		return 0 ;
	}
	
	return 0;
}
