#include<cstdio>
#include<vector>
#include<cstring>
using namespace std;
int main()
{
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	printf("1");
	return 0;
}
