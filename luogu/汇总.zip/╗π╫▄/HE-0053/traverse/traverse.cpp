#include <bits/stdc++.h>
using namespace std;
int T;
int main () {
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	cin >> T;
	while (T--) cout << 1 << '\n';
	return 0;
}
//I give up.
//See you next year.
