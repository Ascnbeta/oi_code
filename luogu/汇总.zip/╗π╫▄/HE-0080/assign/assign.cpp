#include<bits/stdc++.h>
using namespace std;
const int N=1e5+7;
int T;
int n,m,v,c[N],d[N];
int main(){
	freopen("assign.in","w",stdin);
	freopen("assign.out","r",stdout);
	cin>>T;
	while(T--){
		cout<<0<<"\n";
		cin>>n>>m>>v;
		for(int i=1;i<=m;i++){
			cin>>c[i]>>d[i];
		}
	}
	return 0;
}
