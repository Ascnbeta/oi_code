#include <bits/stdc++.h>
using namespace std;
int c, t;
int main(){
	freopen("traverse.in", "r", stdin);
	freopen("traverse.out", "w", stdout);
	ios::sync_with_stdio(0), cin.tie(0);
	cin >> c >> t;
	while(t--){
		int n, k;
		cin >> n >> k;
		for(int i = 1 ; i <= n - 1 ; i++){
			int u, v;
			cin >> u >> v;
		}
		for(int i = 1 ; i <= k ; i++){
			int x;
			cin >> x;
		}
		cout << 1 << '\n';
	}
	return 0;
}
