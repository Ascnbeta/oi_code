#include <bits/stdc++.h>
using namespace std;

int main(){
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	int c,t;
	cin >> c >> t;
	if (c==18){
		while(t--){
			cout << 1 << endl;
		}
	}
	return 0;
} 
