#include <bits/stdc++.h>
using namespace std;

int main(){
	freopen("assign.in","r",stdin);
	freopen("assign.out","w",stdout);
	int t;
	cin >> t;
	while(t--){
		int m,n,v;
		cin >> n >> m >> v;
		while(m--){
			int c,d;
			cin >> c >> d;
			
		}
		cout << 0 << endl;
	}
	return 0;
} 

