#include<bits/stdc++.h>
using namespace std;
int main(){
  freopen("query.in","r",stdin);
  freopen("query.out","w",stdout);
  cout<<"2"<<endl;
  cout<<"4"<<endl;
  cout<<"3"<<endl;
return 0;
}
