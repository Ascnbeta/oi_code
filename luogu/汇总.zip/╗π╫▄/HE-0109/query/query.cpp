#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	cout<<"3\n4\n3"; 
	fclose(stdin);
	fclose(stdout);
	return 0;
}

