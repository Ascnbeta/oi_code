#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	cout<<"952770525\n458942671\n403384174\n717735725\n450995491\n729885956\n41624010\n549302637\n807296290\n542889077";
	fclose(stdin);
	fclose(stdout);
	return 0;
}

