#include<iostream>
#include<algorithm>
#include<string>
#define ll long long
using namespace std;
int main()
{
	freopen("assign.in","r",stdin);
	freopen("assign.out","w",stdout);
	int n,m,w,t;
	cin>>t;
	for(int i=0;i<t;i++)
	{
		cin>>n>>m>>w;
	}
}
