#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("traverse.in", "r", stdin);
	freopen("traverse.out", "w", stdout);
	cout << 3;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
