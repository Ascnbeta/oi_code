#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("assign.in", "r", stdin);
	freopen("assign.out", "w", stdout);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
