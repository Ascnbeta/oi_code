#include<bits/stdc++.h>
using namespace std;
int T;
int main()
{
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	scanf("%d",&T);
	while(T--)puts("0");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
