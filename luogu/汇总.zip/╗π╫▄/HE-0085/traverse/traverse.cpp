#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	int c,T;
	cin>>c>>T;
	while(T--){
		cout<<1<<endl;
	}
}
