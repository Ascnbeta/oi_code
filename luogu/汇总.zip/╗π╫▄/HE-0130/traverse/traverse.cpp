#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	int T;
	cin>>T;
	while(T--)
	{
		cout<<0<<endl;
	}
	return 0;
}
