#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	int T;
	cin>>T;
	while(T--)
	{
		cout<<0<<endl;
	}
	return 0;
}
