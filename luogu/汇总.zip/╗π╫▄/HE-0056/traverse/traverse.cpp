#include <bits/stdc++.h>
using namespace std;
const int N=1e5+7;
int n,k;
void solve()
{
	scanf("%d%d",&n,&k);
	for(int i=1;i<n;++i)
	{
		int u,v;
		scanf("%d%d",&u,&v);
	}
	while(k--)
	{
		int e;
		scanf("%d",&e);
	}
	printf("1\n");
}

signed main()
{
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	int c,T;
	scanf("%d%d",&c,&T);
	while(T--)
	solve();
	return 0;
}
