#include<bits/stdc++.h>
using namespace std;

//kou 1 gei si fen

int c,T;
int main(){
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	cin>>c>>T;
	while(T--)cout<<1<<'\n';
}
