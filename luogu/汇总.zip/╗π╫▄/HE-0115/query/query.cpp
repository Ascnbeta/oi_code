#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	int n;
	int a,b;
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&a,&b);
	}
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cout<<"1"<<endl;
	}
}
