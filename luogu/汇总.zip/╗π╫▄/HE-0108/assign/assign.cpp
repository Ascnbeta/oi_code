#include <iostream>
#include <cstdio>

using namespace std;

int T;

int main () {
	freopen("assign.in", "r", stdin);
	freopen("assign.out", "w", stdout);
	cin >> T;
	while(T--)
		cout << 0 << endl;
	return 0;
}
