#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	return 0;
}
