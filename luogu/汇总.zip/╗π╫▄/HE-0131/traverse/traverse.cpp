#include<bits/stdc++.h>
using namespace std;
int c,T;
int n,k;
int main(){
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	cin>>c>>T;
	for(int t=0;t<T;t++){
		scanf("%d%d",&n,&k);
		for(int i=1;i<=n-1;i++){
			int p1,p2;
			scanf("%d%d",&p1,&p2);
		}
		for(int j=0;j<k;j++){
			int qw;
			scanf("%d",&qw);
		}
		cout<<1;
	}
	return 0;
}
