#include<bits/stdc++.h>
using namespace std;
const int M=1e5+1;
int main()
{
	freopen("edit.in","r",stdin);
	freopen("esit.out","w",stdout);
	return 0;
}
