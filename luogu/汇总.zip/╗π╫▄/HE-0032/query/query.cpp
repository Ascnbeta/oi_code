#include<bits/stdc++.h>
using namespace std;
const int N=1e4+10;
int n,q,fa[N],
vector<int> e[N];
int main(){
	
}