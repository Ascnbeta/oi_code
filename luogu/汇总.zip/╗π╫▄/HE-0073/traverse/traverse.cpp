#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
	freopen("traverse.in","r",stdin);
	freopen("traverse.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	return 0;
}

