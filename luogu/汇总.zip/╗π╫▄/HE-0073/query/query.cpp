#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
	freopen("query.in","r",stdin);
	freopen("query.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	return 0;
}

